
import java.io.File;

import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import Generic.BaseClass;
import Generic.Utilities;
import Objects.LoginElement;

public class LoginTest extends BaseClass{
	Utilities util = new Utilities();

	public String mobNumber="2345676567";
	public String invalidmobNumber ="00000000000";
	public String characters ="abcd";

	String formatinvalid_Expected = "The mobile format is invalid.";
	
	@Test(priority = 1)
	public void TestCase_enterValidMobileNumber_Verify() {
		LoginElement lE = new LoginElement(driver);
		lE.openAccountClick();
		lE.enterMobileNumber(mobNumber);
	    System.out.println("Valid mobile number is entered successfully");
	    lE.verifyButtonClick(); 
	    
	}
	@Test(priority = 2)
	public void TestCase_enterInvalidMobileNumber_Verify() {
		LoginElement lE = new LoginElement(driver);
		lE.openAccountClick();
		lE.enterInvalidMobileNumber(invalidmobNumber);
		System.out.println("Invalid mobile number is entered successfully");
		lE.verifyButtonClick();

		util.ewait(driver, lE.elementFormatPopUpBox());
		lE.okButtonClick();
	}
	@Test(priority = 3)
	public void TestCase_enterMobileNumberWithCharacters_Verify() {
		LoginElement lE = new LoginElement(driver);
		lE.openAccountClick();
        lE.enterMobileNumberWithCharacters(characters);
        System.out.println("Unable to enter Characters");
	}

	@Test(priority = 4)
	public void TestCase_enterMobileNumberwith_Verify() {
		LoginElement lE = new LoginElement(driver);
		lE.openAccountClick();
		lE.enterMobileNumberWithBlank("");
		System.out.println("Mobile number field left as Blank");

		util.ewaitinvisibility(driver, lE.verifyButton());
	    System.out.println("Unable to proceed if left the mobile number field as blank");
	}
}
