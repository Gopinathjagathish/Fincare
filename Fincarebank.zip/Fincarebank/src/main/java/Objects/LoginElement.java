package Objects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginElement {

	public LoginElement(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//a[contains(text(),'Open Account')]" )
	private WebElement openaccount;
	@FindBy(xpath = "//input[@name='mobile']" )
	private WebElement mobile;
	@FindBy(xpath = "//input[@id='verifyBtn']" )
	private WebElement verifybutton;

	@FindBy(xpath = "//div/span[contains(text(),'The mobile format is invalid.')]/ancestor::div[@class='modal-dialog']")
	private String errormessage_formatInvalid;

	@FindBy(xpath = "//button[contains(text(),'OK')]")
	private WebElement okbutton;

	@FindBy(xpath="//div[@class='modal-content modal mobile_check_div hide_cls']")
	WebElement elementFormatPopUp;

	public WebElement openAccount() {
		return openaccount;
	}
	public WebElement mobileNumber() {
		return mobile;
	}
	public WebElement verifyButton() {
		return verifybutton;
	}

	public String errorMessage() {
		return errormessage_formatInvalid;
	}

	public WebElement okButton() {
		return okbutton;
	}

	public WebElement elementFormatPopUpBox() {
		return elementFormatPopUp;
	}

	public void openAccountClick() {
		openAccount().click();

	}
	public void verifyButtonClick() {
		verifyButton().click();
	}

	public void enterMobileNumber(String mnumber) {
		mobileNumber().sendKeys(mnumber);

	}
	public void enterInvalidMobileNumber(String imnumber) {
		mobileNumber().sendKeys(imnumber);

	}
	public void enterMobileNumberWithCharacters(String characters) {
		mobileNumber().sendKeys(characters);

	}
	public void enterMobileNumberWithSpecialCharacters(String speccharacters) {
		mobileNumber().sendKeys(speccharacters);

	}
	public void enterMobileNumberWithBlank(String blank) {
		mobileNumber().sendKeys(blank);

	}

	public void okButtonClick() {
		okButton().click();

	}



}
