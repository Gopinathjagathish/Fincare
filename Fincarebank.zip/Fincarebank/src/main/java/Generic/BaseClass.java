package Generic;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;

import com.aventstack.extentreports.ExtentReporter;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;


//import PageObjectModule.LoginPage;

public class BaseClass {

public WebDriver driver;



	@BeforeMethod
	public void browserLaunch() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "C:\\Driver\\chromedriver.exe");

		driver = new ChromeDriver();
		driver.get("https://101.fincarebank.com/");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20l));
		driver.manage().window().maximize();
		Thread.sleep(2000);
        System.out.println("Browser opened");
	}

	@AfterMethod
	public void browserClose() {

		driver.close();
		driver.quit();
		System.out.println("Browser closed................................");

	}



}
